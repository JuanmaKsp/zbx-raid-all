#!/bin/bash
# zbx_raid_collect.sh — LLD JSON para ZFS + ssacli + storcli (sin jq)
set -euo pipefail

umask 022
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

DATADIR=/var/lib/zbx-raid
BACKEND_DIR=/usr/lib/zbx-raid
mkdir -p "$DATADIR"

# fichero temporal: cada línea contiene un objeto JSON
tmp_lines="$(mktemp)"
tmp_json="${DATADIR}/pools_discovery.json.tmp"
trap 'rm -f "$tmp_lines" "$tmp_json" 2>/dev/null || true' EXIT

# ---- ZFS ----
if command -v zpool >/dev/null 2>&1 && [[ -x "$BACKEND_DIR/backend_zfs.sh" ]]; then
  while IFS=';' read -r poolname state; do
    [[ -n "${poolname:-}" ]] || continue
    printf '{"{#POOLID}":"%s","{#BACKEND}":"%s","{#POOLNAME}":"%s"}\n' \
           "zfs_${poolname}" "zfs" "$poolname" >>"$tmp_lines"
    echo "${state:-UNKNOWN}" >"$DATADIR/pool_zfs_${poolname}.state"
  done < <("$BACKEND_DIR/backend_zfs.sh")
fi

# ---- SSACLI (HPE SmartArray) ----
if command -v ssacli >/dev/null 2>&1 && [[ -x "$BACKEND_DIR/backend_ssacli.sh" ]]; then
  while IFS=';' read -r poolid poolname state; do
    [[ -n "${poolid:-}" ]] || continue
    printf '{"{#POOLID}":"%s","{#BACKEND}":"%s","{#POOLNAME}":"%s"}\n' \
           "$poolid" "ssacli" "$poolname" >>"$tmp_lines"
    echo "${state:-UNKNOWN}" >"$DATADIR/pool_${poolid}.state"
  done < <("$BACKEND_DIR/backend_ssacli.sh")
fi

# ---- STORCLI (Broadcom/LSI MegaRAID) ----
if { command -v storcli64 >/dev/null 2>&1 || [[ -x "/opt/MegaRAID/storcli/storcli64" ]]; } \
   && [[ -x "$BACKEND_DIR/backend_storcli.sh" ]]; then
  while IFS=';' read -r poolid poolname state; do
    [[ -n "${poolid:-}" ]] || continue
    printf '{"{#POOLID}":"%s","{#BACKEND}":"%s","{#POOLNAME}":"%s"}\n' \
           "$poolid" "storcli" "$poolname" >>"$tmp_lines"
    echo "${state:-UNKNOWN}" >"$DATADIR/pool_${poolid}.state"
  done < <("$BACKEND_DIR/backend_storcli.sh")
fi

# ---- Ensamblar JSON final SIN jq ----
# Construye: {"data":[<linea1>,<linea2>,...]}
{
  echo -n '{"data":['
  awk 'length>0 { if (n) printf(","); printf("%s",$0); n=1 } END { printf("]}") }' "$tmp_lines"
} >"$tmp_json"

# Instala con permisos 644 siempre
install -m 644 "$tmp_json" "${DATADIR}/pools_discovery.json"

