#!/bin/bash
set -euo pipefail

DATADIR="/var/lib/zbx-raid"
BACKEND_DIR="/usr/lib/zbx-raid"

mkdir -p "$DATADIR"

tmp_json="$(mktemp)"
echo '{"data":[' > "$tmp_json"
first=1

# Función auxiliar para añadir un pool al JSON y crear fichero de estado
add_pool() {
    local poolid backend poolname state
    poolid="$1"
    backend="$2"
    poolname="$3"
    state="$4"

    # Estado -> fichero
    echo "$state" > "${DATADIR}/pool_${poolid}.state"

    # JSON LLD
    if [ "$first" -eq 0 ]; then
        echo ',' >> "$tmp_json"
    fi
    printf '{"{#POOLID}":"%s","{#BACKEND}":"%s","{#POOLNAME}":"%s"}' \
        "$poolid" "$backend" "$poolname" >> "$tmp_json"
    first=0
}

# 1) ZFS
if command -v zpool >/dev/null 2>&1 && [ -x "${BACKEND_DIR}/backend_zfs.sh" ]; then
    "${BACKEND_DIR}/backend_zfs.sh" | while IFS=';' read -r poolname state; do
        [ -z "$poolname" ] && continue
        poolid="zfs_${poolname}"
        add_pool "$poolid" "zfs" "$poolname" "$state"
    done
fi

# 2) ssacli
if command -v ssacli >/dev/null 2>&1 || command -v hpssacli >/dev/null 2>&1; then
    if [ -x "${BACKEND_DIR}/backend_ssacli.sh" ]; then
        "${BACKEND_DIR}/backend_ssacli.sh" | while IFS=";" read -r poolid poolname state; do
            [ -z "$poolid" ] && continue
            add_pool "$poolid" "ssacli" "$poolname" "$state"
        done
    fi
fi

# 3) storcli
if command -v storcli64 >/dev/null 2>&1 || [ -x /opt/MegaRAID/storcli/storcli64 ]; then
    if [ -x "${BACKEND_DIR}/backend_storcli.sh" ]; then
        "${BACKEND_DIR}/backend_storcli.sh" | while IFS=";" read -r poolid poolname state; do
            [ -z "$poolid" ] && continue
            add_pool "$poolid" "storcli" "$poolname" "$state"
        done
    fi
fi

echo ']}' >> "$tmp_json"
mv "$tmp_json" "${DATADIR}/pools_discovery.json"
