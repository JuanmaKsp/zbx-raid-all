#!/bin/bash
set -euo pipefail

# Backend para controladoras LSI/DELL usando storcli64.
# Salida: una línea por virtual drive:
#   POOLID;POOLNAME;STATE
#   ej: storcli_c0_vd0;VD0;OK

CLI=""

# 1) Localizar binario storcli64
for bin in /opt/MegaRAID/storcli/storcli64 /usr/sbin/storcli64 storcli64; do
    if command -v "$bin" >/dev/null 2>&1 || [ -x "$bin" ]; then
        CLI="$(command -v "$bin" 2>/dev/null || echo "$bin")"
        break
    fi
done

# Si no hay CLI, salimos sin error (el colector simplemente no tendrá pools storcli)
[ -z "$CLI" ] && exit 0

# 2) Ejecutar storcli y parsear
"$CLI" /cALL /vall show all 2>/dev/null | awk '
    BEGIN {
        ctrl = "0"
        in_table = 0
    }

    # Detectar controlador actual:
    #   Controller = 0
    /^Controller =/ {
        ctrl = $3
    }

    # Inicio de la tabla de VDs:
    # DG/VD TYPE  State Access Consist Cache ...
    /^DG\/VD[[:space:]]+TYPE[[:space:]]+State/ {
        in_table = 1
        next
    }

    # Fin de la tabla cuando aparece la línea de guiones o una línea vacía
    /^-+/ && in_table {
        # dejamos que guiones iniciales pasen, pero si ya teníamos datos,
        # consideramos que la tabla ha terminado
        # en tu salida hay una línea de guiones antes y otra después,
        # así que simplemente seguimos y dejamos de procesar cuando no haya más "DG/VD"
        next
    }

    # Filas de datos de la tabla: empiezan por algo tipo "0/0"
    in_table && /^[0-9]+\/[0-9]+/ {
        dg_vd = $1      # ej: "0/0"
        state_raw = $3  # ej: "Optl"

        # Extraer DG y VD
        split(dg_vd, a, "/")
        dg = a[1]
        vd = a[2]

        # Mapear estado de storcli a estado genérico
        state = state_raw

        if (state_raw ~ /^(Optl|Optimal)$/) {
            state = "OK"
        }
        else if (state_raw ~ /(Pdgd|Dgrd|Rec|Rbld|Rebuild|Rebuilding)/i) {
            state = "DEGRADED"
        }
        else if (state_raw ~ /(OfLn|Offln|Offline)/i) {
            state = "OFFLINE"
        }
        else if (state_raw ~ /Fail/i) {
            state = "FAILED"
        }

        poolid   = sprintf("storcli_c%s_vd%s", ctrl, vd)
        poolname = sprintf("VD%s", vd)

        printf "%s;%s;%s\n", poolid, poolname, state
    }
'
