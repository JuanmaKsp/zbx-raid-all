#!/bin/bash
set -euo pipefail

# Salida: una línea por pool -> "nombre;estado"
# Ejemplo:
#   rpool;OK
#   local-zfs1;DEGRADED

zpool list -H -o name,health 2>/dev/null | while read -r name health; do
    [ -z "$name" ] && continue
    case "$health" in
        ONLINE)   state="OK" ;;
        DEGRADED) state="DEGRADED" ;;
        FAULTED|OFFLINE) state="FAILED" ;;
        *)        state="$health" ;;
    esac
    echo "${name};${state}"
done
