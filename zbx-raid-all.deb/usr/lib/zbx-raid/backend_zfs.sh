#!/bin/bash
set -euo pipefail

# Salida: una línea por pool -> "nombre;estado"
# Ejemplo:
#   rpool;OK
#   local-zfs1;DEGRADED

zpool list -H -o name,health 2>/dev/null | while read -r name health; do
    [ -z "$name" ] && continue
    case "$health" in
        ONLINE)   state="OK" ;;# Funcionamiento normal
        DEGRADED) state="DEGRADED" ;;# Funciona pero con tolerancia reducida
        FAULTED|UNAVAIL|REMOVED) state="FAILED" ;;# Pool o dispositivo inaccesible / roto
        OFFLINE)  state="OFFLINE" ;;# Lo ha puesto offline el admin
        *)        state="$health" ;;# Cualquier otro: dejamos el valor literal por si ZFS añade nuevos
    esac
    echo "${name};${state}"
done
