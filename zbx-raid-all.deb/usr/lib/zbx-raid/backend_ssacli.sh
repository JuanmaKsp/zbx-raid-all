#!/bin/bash
set -euo pipefail

# Backend para controladoras HP Smart Array usando ssacli/hpssacli.
# Salida: una línea por logical drive:
#   POOLID;POOLNAME;STATE
#   ej: ssacli_c4_ld1;LD1;OK

# 1) Localizar binario ssacli/hpssacli
CLI=""

for bin in /usr/sbin/ssacli /usr/sbin/hpssacli ssacli hpssacli; do
    if command -v "$bin" >/dev/null 2>&1 || [ -x "$bin" ]; then
        CLI="$(command -v "$bin" 2>/dev/null || echo "$bin")"
        break
    fi
done

# Si no hay CLI, no hacemos nada (el colector simplemente no tendrá pools ssacli)
[ -z "$CLI" ] && exit 0

# 2) Ejecutar ssacli y parsear
"$CLI" ctrl all show config detail 2>/dev/null | awk '
    BEGIN {
        ctrl = "0"
        in_ld = 0
        ld = ""
    }

    # Ejemplo de cabecera:
    # Smart HBA H240 in Slot 4 (RAID Mode)
    /^Smart (Array|HBA)/ && / in Slot / {
        # Extraer número de Slot (compatible con mawk)
        if (match($0, /Slot[[:space:]]+[0-9]+/)) {
            slot = substr($0, RSTART, RLENGTH)
            gsub(/[^0-9]/, "", slot)   # dejar solo el número
            ctrl = slot
        }
    }


    # Inicio de bloque de logical drive:
    #   Logical Drive: 1
    /^ *Logical Drive: [0-9]+/ {
        ld = $3
        gsub(/[^0-9]/, "", ld)   # dejar solo número
        in_ld = 1
        next
    }

    # Dentro de un logical drive, la primera línea "Status: X" es la que nos interesa:
    #   Status: OK
    /^ *Status: / && in_ld && ld != "" {
        state_raw = $2
        state = state_raw

        # Mapeo a estados genéricos
        if (state_raw ~ /^OK$/) {
            state = "OK"
        }
        else if (state_raw ~ /Degrad|Recover|Rebuild|Interim/i) {
            state = "DEGRADED"
        }
        else if (state_raw ~ /Offline/i) {
            state = "OFFLINE"
        }
        else if (state_raw ~ /Fail/i) {
            state = "FAILED"
        }

        poolid   = sprintf("ssacli_c%s_ld%s", ctrl, ld)
        poolname = sprintf("LD%s", ld)

        printf "%s;%s;%s\n", poolid, poolname, state

        # Ya hemos consumido este logical drive
        in_ld = 0
        ld = ""
        next
    }

    # Línea en blanco -> salimos del bloque de LD por si acaso
    /^$/ {
        in_ld = 0
        ld = ""
    }
'
